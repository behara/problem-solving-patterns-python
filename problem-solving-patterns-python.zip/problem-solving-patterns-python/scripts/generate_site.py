"""Build the pattern notes and static browser catalog from Python source files."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# id, slug, title, recognition cue, central invariant, worked example, common trap
PATTERNS = [
    (1, "sliding_window", "Sliding Window", "A question asks about contiguous subarrays or substrings.", "Update a running window as its left and right boundaries move.", "For [1, 3, 2, 6] with k=2, the largest window sum is 8, so its average is 4.", "A shrinking sum window needs positive values; negative values break the monotonic argument."),
    (2, "two_pointers", "Two Pointers", "Sorted data or a pair/triple constraint lets you rule out candidates from an end.", "Move the pointer whose movement can improve the current comparison.", "In [1, 2, 4, 7], target 6 is found at indices (1, 2).", "For 3Sum, sort a copy and skip duplicate anchors and pairs."),
    (3, "fast_slow_pointers", "Fast and Slow Pointers", "A linked list may contain a cycle, or you need its midpoint.", "Advance one reference once and the other twice per iteration.", "In 1 → 2 → 3 → 4, the second middle is node 3.", "Check fast.next before advancing two links."),
    (4, "merge_intervals", "Merge Intervals", "Ranges must be combined, inserted, or checked for conflicts.", "Sort by start, then extend the current merged interval when starts overlap.", "[(1,3), (2,5), (8,9)] becomes [(1,5), (8,9)].", "Decide whether touching endpoints overlap; these examples use closed intervals."),
    (5, "cyclic_sort", "Cyclic Sort", "Values lie in a small index-related range such as 1..n.", "Swap each in-range value toward its natural index until it is placed or duplicated.", "[3,1,2] becomes [1,2,3] after cyclic placement.", "Check for duplicate values before swapping or a loop can run forever."),
    (6, "reverse_linked_list", "In-place Linked List Reversal", "A linked-list segment must be reversed without new nodes.", "Save the next link, redirect the current link, then advance.", "1 → 2 → 3 becomes 3 → 2 → 1.", "Save next before overwriting current.next."),
    (7, "tree_bfs", "Tree Breadth-first Search", "A tree question refers to levels, shortest root-to-leaf depth, or neighbors first.", "Use a FIFO queue and process exactly the current queue length for each level.", "For root 1 with children 2 and 3, levels are [[1], [2,3]].", "For minimum depth, stop at a leaf, not at a node missing just one child."),
    (8, "tree_dfs", "Tree Depth-first Search", "A tree question asks for root-to-leaf paths or aggregates along a branch.", "Carry path state down and restore it while returning from recursion.", "A path 5 → 4 → 1 satisfies target sum 10.", "Only a true leaf completes a root-to-leaf path."),
    (9, "two_heaps", "Two Heaps", "A stream needs its median, or choices split into available and prioritized groups.", "Use a max heap for the lower half and a min heap for the upper half.", "After inserting 2, 7, and 4, the median is 4.", "Python heapq is a min heap; negate keys for max-heap behavior."),
    (10, "subsets", "Subsets and Permutations", "A task asks to enumerate choices, orderings, or a power set.", "Build partial solutions by adding each new value or recursively choosing unused values.", "Subsets of [1,2] are [], [1], [2], [1,2].", "Output size is exponential or factorial; include it in complexity."),
    (11, "binary_search", "Modified Binary Search", "Input is sorted, rotated, or has a monotone decision boundary.", "At each step identify a half that cannot contain the answer.", "Searching 0 in [4,5,6,0,1,2] returns index 3.", "The rotated-array version assumes distinct values."),
    (12, "bitwise_xor", "Bitwise XOR", "Paired equal values cancel and one or two values remain unmatched.", "Use x ^ x = 0 and partition by a differing set bit for two singletons.", "3 ^ 5 ^ 3 equals 5.", "The two-singleton function assumes exactly two distinct unpaired values."),
    (13, "top_k", "Top K Elements", "A question asks for the kth largest value or most frequent few values.", "Keep a heap of only candidates that still belong in the top k.", "The 2nd largest of [3,2,1,5,6,4] is 5.", "Specify tie behavior for equal frequencies."),
    (14, "k_way_merge", "K-way Merge", "Several sorted sequences must be traversed as one.", "Put the next item from each source in a min heap.", "Merging [1,4] and [2,3] yields [1,2,3,4].", "Store the source and position with each heap item."),
    (15, "knapsack_dp", "0/1 Knapsack and Dynamic Programming", "Each item may be selected once under a sum or capacity constraint.", "A one-dimensional DP array records the best answer for each capacity; update backward.", "Weights [2,3], values [4,5], capacity 3 gives value 5.", "Forward capacity updates reuse an item and turn 0/1 knapsack into unbounded knapsack."),
    (16, "topological_sort", "Topological Sort", "Tasks have directed prerequisites or dependency ordering.", "Remove zero-indegree vertices and decrement their outgoing neighbors.", "With edges 0→1 and 1→2, the order is [0,1,2].", "A partial order indicates a directed cycle."),
    (17, "trie", "Trie (Prefix Tree)", "Many queries ask whether words or prefixes exist in a dictionary.", "Store shared prefixes once, one character per edge.", "After inserting 'cat', searches for 'cat' and prefix 'ca' succeed.", "A word ending must be marked separately from merely having a prefix."),
    (18, "union_find", "Union Find (Disjoint Set)", "Undirected connections arrive over time and component membership matters.", "Compress find paths and attach smaller trees under larger trees.", "Union(0,1) then union(1,2) leaves 0,1,2 in one component.", "Union find does not itself answer directed reachability."),
    (19, "monotonic_stack", "Monotonic Stack", "The next greater/smaller element or waiting distance is needed.", "Keep unresolved indices in monotonic order; pop them when a new value resolves them.", "Next greater values for [2,1,3] are [3,3,-1].", "Store indices when the answer is a distance."),
    (20, "prefix_sum", "Prefix Sum", "Many range sums or counts of subarrays with a target sum are needed.", "Subtract prefix totals; count earlier prefixes equal to current minus target.", "In [1,1,1], two subarrays sum to 2.", "Seed prefix frequency 0 with one empty prefix; this handles subarrays starting at index 0."),
    (21, "islands", "Island / Matrix Traversal", "A 2D board has connected regions or simultaneous spreading.", "Treat each cell as a graph vertex with four implicit neighbors.", "[['1','0'],['1','1']] has one island.", "For simultaneous spread, put all initial sources in the BFS queue before traversal."),
    (22, "backtracking", "Backtracking", "A search must enumerate valid choices under constraints.", "Choose, recurse, and undo; prune branches that cannot finish.", "Choosing two from 1..3 gives [1,2], [1,3], [2,3].", "Always undo mutable path or visited state before returning."),
    (23, "shortest_path", "Shortest Path", "A graph asks for minimum route cost.", "Use Dijkstra for nonnegative edges or Bellman-Ford when negative weights are possible.", "Edges 0→1 (2), 1→2 (3) give distance 5 from 0 to 2.", "Dijkstra is invalid with negative edge weights."),
    (24, "greedy", "Greedy Algorithms", "A locally optimal choice can be proved safe for the whole problem.", "Choose the earliest finishing interval or maintain the farthest reachable jump.", "For intervals (1,2), (2,3), (1,3), choose two nonoverlapping intervals.", "A plausible local rule is not enough; prove it by an exchange argument or invariant."),
    (25, "bit_manipulation", "Bit Manipulation", "The state is naturally a small set of bits or a fixed-width integer.", "Use masks and bit identities such as n & (n-1) to clear the lowest set bit.", "12 is binary 1100 and has two set bits.", "Python integers have no fixed width; mask or bound values for 32-bit operations."),
    (26, "data_structure_design", "Data Structure Design", "Several operations must all meet tight time bounds.", "Combine a dictionary with order or an indexable list with a position map.", "An LRU cache with capacity 2 evicts the least recently used key on a third insert.", "On removal from RandomizedSet, update the moved element's index."),
]

def build() -> None:
    docs_dir = ROOT / "docs"
    docs_dir.mkdir(exist_ok=True)
    site_dir = ROOT / "site"
    site_dir.mkdir(exist_ok=True)
    catalog = []
    table = []
    for number, slug, title, cue, idea, example, trap in PATTERNS:
        module = f"p{number:02d}_{slug}"
        source = (ROOT / "dsa_patterns" / f"{module}.py").read_text()
        doc_file = f"{number:02d}-{slug.replace('_', '-')}.md"
        content = (f"# {number:02d}. {title}\n\n"
                   f"## When to use it\n\n{cue}\n\n"
                   f"## Core idea\n\n{idea}\n\n"
                   f"## Example\n\n{example}\n\n"
                   f"## Watch out\n\n{trap}\n\n"
                   f"## Python implementation\n\n"
                   f"The source is [`dsa_patterns/{module}.py`](../dsa_patterns/{module}.py). "
                   f"Functions document their time and space costs.\n\n"
                   f"```python\n{source.rstrip()}\n```\n")
        (docs_dir / doc_file).write_text(content)
        catalog.append(dict(id=number, slug=slug, title=title, cue=cue, idea=idea, example=example, trap=trap, module=module, doc=doc_file, source=source))
        table.append(f"| {number:02d} | [{title}](docs/{doc_file}) | [`{module}.py`](dsa_patterns/{module}.py) |")
    (site_dir / "patterns.json").write_text(json.dumps(catalog, indent=2) + "\n")
    readme = """# Problem Solving Patterns in Python

A fresh Python companion to the [26-pattern reference](https://github.com/rohitkr7/problem-solving-patterns). Each pattern has a concise note and runnable, standard-library-only Python implementations. The examples include representative problems from [AlgoMaster's DSA pattern practice list](https://algomaster.io/practice/dsa-patterns), alongside classic interview patterns from the reference repo. This repository is independently authored; it does not copy the other repo's Git history or Java solutions.

## Explore

- Read the [pattern notes](docs/) or browse the table below.
- Run `python3 -m unittest discover -s tests -v` from the repo root.
- Run `python3 -m http.server 8000`, then open [http://localhost:8000/site/](http://localhost:8000/site/) to browse and search the patterns locally.
- Import directly, for example `from dsa_patterns.p01_sliding_window import maximum_average`.

Python 3.10+ is required. There are no third-party runtime dependencies. The browser viewer loads the generated `site/patterns.json`; after editing source or pattern metadata, run `python3 scripts/generate_site.py` to rebuild the notes and catalog.

## Pattern index

| # | Pattern notes | Python source |
|---:|---|---|
""" + "\n".join(table) + "\n\n## Conventions\n\nInputs and return values are described in each function docstring. In-place operations say so explicitly. Indices are zero-based unless a function says otherwise. Error cases raise `ValueError` for invalid constraints and `IndexError` for invalid range access.\n"
    (ROOT / "README.md").write_text(readme)
    print(f"Generated {len(catalog)} notes and site entries")

if __name__ == "__main__":
    build()
