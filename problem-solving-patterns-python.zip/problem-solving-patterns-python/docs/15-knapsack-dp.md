# 15. 0/1 Knapsack and Dynamic Programming

## When to use it

Each item may be selected once under a sum or capacity constraint.

## Core idea

A one-dimensional DP array records the best answer for each capacity; update backward.

## Example

Weights [2,3], values [4,5], capacity 3 gives value 5.

## Watch out

Forward capacity updates reuse an item and turn 0/1 knapsack into unbounded knapsack.

## Python implementation

The source is [`dsa_patterns/p15_knapsack_dp.py`](../dsa_patterns/p15_knapsack_dp.py). Functions document their time and space costs.

```python
"""0/1 dynamic programming: each item is used at most once."""

def knapsack_01(weights: list[int], values: list[int], capacity: int) -> int:
    """Maximum value within capacity. O(nC) time, O(C) space."""
    if len(weights) != len(values) or capacity < 0 or any(w <= 0 for w in weights):
        raise ValueError("invalid items or capacity")
    best = [0] * (capacity + 1)
    for weight, value in zip(weights, values):
        for limit in range(capacity, weight - 1, -1):
            best[limit] = max(best[limit], best[limit - weight] + value)
    return best[capacity]


def can_partition_equal(nums: list[int]) -> bool:
    """Whether nonnegative values split into equal sums. O(nS) time, O(S) space."""
    if any(value < 0 for value in nums):
        raise ValueError("values must be nonnegative")
    total = sum(nums)
    if total % 2:
        return False
    target = total // 2
    reachable = {0}
    for value in nums:
        reachable |= {subtotal + value for subtotal in reachable if subtotal + value <= target}
    return target in reachable
```
