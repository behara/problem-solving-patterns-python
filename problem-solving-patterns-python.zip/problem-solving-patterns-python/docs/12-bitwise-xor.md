# 12. Bitwise XOR

## When to use it

Paired equal values cancel and one or two values remain unmatched.

## Core idea

Use x ^ x = 0 and partition by a differing set bit for two singletons.

## Example

3 ^ 5 ^ 3 equals 5.

## Watch out

The two-singleton function assumes exactly two distinct unpaired values.

## Python implementation

The source is [`dsa_patterns/p12_bitwise_xor.py`](../dsa_patterns/p12_bitwise_xor.py). Functions document their time and space costs.

```python
"""XOR: equal values cancel, leaving unmatched bits."""

def single_number(nums: list[int]) -> int:
    """One value occurs once; all others twice. O(n) time, O(1) space."""
    result = 0
    for value in nums:
        result ^= value
    return result


def two_single_numbers(nums: list[int]) -> tuple[int, int]:
    """Two values occur once; all others twice. O(n) time, O(1) space."""
    combined = single_number(nums)
    if combined == 0:
        raise ValueError("two distinct singleton values required")
    low_bit = combined & -combined
    first = second = 0
    for value in nums:
        if value & low_bit:
            first ^= value
        else:
            second ^= value
    return first, second
```
