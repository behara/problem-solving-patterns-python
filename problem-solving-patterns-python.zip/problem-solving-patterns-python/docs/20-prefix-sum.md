# 20. Prefix Sum

## When to use it

Many range sums or counts of subarrays with a target sum are needed.

## Core idea

Subtract prefix totals; count earlier prefixes equal to current minus target.

## Example

In [1,1,1], two subarrays sum to 2.

## Watch out

Seed prefix frequency 0 with one empty prefix; this handles subarrays starting at index 0.

## Python implementation

The source is [`dsa_patterns/p20_prefix_sum.py`](../dsa_patterns/p20_prefix_sum.py). Functions document their time and space costs.

```python
"""Prefix sums: turn a range sum into a difference of totals."""
from collections import defaultdict

class RangeSum:
    """O(n) construction; O(1) inclusive range query; O(n) space."""
    def __init__(self, nums: list[int]) -> None:
        self.prefix = [0]
        for value in nums:
            self.prefix.append(self.prefix[-1] + value)

    def query(self, left: int, right: int) -> int:
        if not 0 <= left <= right < len(self.prefix) - 1:
            raise IndexError("invalid range")
        return self.prefix[right + 1] - self.prefix[left]


def count_subarrays_with_sum(nums: list[int], target: int) -> int:
    """Count subarrays summing to target, including negative values. O(n) time."""
    frequencies = defaultdict(int, {0: 1})
    total = answer = 0
    for value in nums:
        total += value
        answer += frequencies[total - target]
        frequencies[total] += 1
    return answer
```
