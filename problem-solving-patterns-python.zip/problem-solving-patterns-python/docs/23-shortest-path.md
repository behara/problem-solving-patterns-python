# 23. Shortest Path

## When to use it

A graph asks for minimum route cost.

## Core idea

Use Dijkstra for nonnegative edges or Bellman-Ford when negative weights are possible.

## Example

Edges 0→1 (2), 1→2 (3) give distance 5 from 0 to 2.

## Watch out

Dijkstra is invalid with negative edge weights.

## Python implementation

The source is [`dsa_patterns/p23_shortest_path.py`](../dsa_patterns/p23_shortest_path.py). Functions document their time and space costs.

```python
"""Shortest paths: use Dijkstra for nonnegative edges, Bellman-Ford otherwise."""
import heapq
from math import inf

def dijkstra(graph: dict[int, list[tuple[int, int]]], start: int) -> dict[int, float]:
    """Distances from start; unreachable vertices are infinity. O((V+E) log V)."""
    if any(weight < 0 for edges in graph.values() for _, weight in edges):
        raise ValueError("Dijkstra requires nonnegative weights")
    vertices = set(graph) | {start} | {neighbor for edges in graph.values() for neighbor, _ in edges}
    distances = {vertex: inf for vertex in vertices}
    distances[start] = 0
    heap = [(0, start)]
    while heap:
        distance, vertex = heapq.heappop(heap)
        if distance != distances[vertex]:
            continue
        for neighbor, weight in graph.get(vertex, []):
            candidate = distance + weight
            if candidate < distances[neighbor]:
                distances[neighbor] = candidate
                heapq.heappush(heap, (candidate, neighbor))
    return distances


def bellman_ford(vertices: int, edges: list[tuple[int, int, int]], start: int) -> list[float]:
    """Distances with negative edges; reject reachable negative cycles. O(VE)."""
    if not 0 <= start < vertices or any(not (0 <= u < vertices and 0 <= v < vertices) for u, v, _ in edges):
        raise ValueError("vertex out of range")
    distances = [inf] * vertices
    distances[start] = 0
    for _ in range(vertices - 1):
        changed = False
        for source, target, weight in edges:
            if distances[source] != inf and distances[source] + weight < distances[target]:
                distances[target] = distances[source] + weight
                changed = True
        if not changed:
            break
    if any(distances[u] != inf and distances[u] + weight < distances[v] for u, v, weight in edges):
        raise ValueError("reachable negative cycle")
    return distances
```
