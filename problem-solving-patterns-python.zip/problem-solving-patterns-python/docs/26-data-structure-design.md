# 26. Data Structure Design

## When to use it

Several operations must all meet tight time bounds.

## Core idea

Combine a dictionary with order or an indexable list with a position map.

## Example

An LRU cache with capacity 2 evicts the least recently used key on a third insert.

## Watch out

On removal from RandomizedSet, update the moved element's index.

## Python implementation

The source is [`dsa_patterns/p26_data_structure_design.py`](../dsa_patterns/p26_data_structure_design.py). Functions document their time and space costs.

```python
"""Composite data structures: combine primitives to meet operation bounds."""
from collections import OrderedDict
import random

class LRUCache:
    """O(1) average get/put using a hash table with recency order."""
    def __init__(self, capacity: int) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self.capacity = capacity
        self.items: OrderedDict[int, int] = OrderedDict()

    def get(self, key: int) -> int:
        if key not in self.items:
            return -1
        self.items.move_to_end(key)
        return self.items[key]

    def put(self, key: int, value: int) -> None:
        self.items[key] = value
        self.items.move_to_end(key)
        if len(self.items) > self.capacity:
            self.items.popitem(last=False)

class RandomizedSet:
    """O(1) average insert/remove/random using a list and index map."""
    def __init__(self) -> None:
        self.values: list[int] = []
        self.positions: dict[int, int] = {}

    def insert(self, value: int) -> bool:
        if value in self.positions:
            return False
        self.positions[value] = len(self.values)
        self.values.append(value)
        return True

    def remove(self, value: int) -> bool:
        if value not in self.positions:
            return False
        index = self.positions.pop(value)
        last = self.values.pop()
        if index < len(self.values):
            self.values[index] = last
            self.positions[last] = index
        return True

    def get_random(self) -> int:
        if not self.values:
            raise ValueError("set is empty")
        return random.choice(self.values)
```
