# 06. In-place Linked List Reversal

## When to use it

A linked-list segment must be reversed without new nodes.

## Core idea

Save the next link, redirect the current link, then advance.

## Example

1 → 2 → 3 becomes 3 → 2 → 1.

## Watch out

Save next before overwriting current.next.

## Python implementation

The source is [`dsa_patterns/p06_reverse_linked_list.py`](../dsa_patterns/p06_reverse_linked_list.py). Functions document their time and space costs.

```python
"""Reverse linked-list links without allocating replacement nodes."""
from .p03_fast_slow_pointers import ListNode

def reverse_list(head: ListNode | None) -> ListNode | None:
    """Reverse an entire list. O(n) time, O(1) space."""
    prev = None
    while head:
        next_node = head.next
        head.next = prev
        prev, head = head, next_node
    return prev


def reverse_between(head: ListNode | None, left: int, right: int) -> ListNode | None:
    """Reverse one-based inclusive positions. O(n) time, O(1) space."""
    if left < 1 or right < left:
        raise ValueError("invalid positions")
    sentinel = ListNode(0, head)
    before = sentinel
    for _ in range(left - 1):
        if before.next is None:
            raise ValueError("position exceeds list length")
        before = before.next
    current = before.next
    if current is None:
        raise ValueError("position exceeds list length")
    for _ in range(right - left):
        if current.next is None:
            raise ValueError("position exceeds list length")
        moving = current.next
        current.next = moving.next
        moving.next = before.next
        before.next = moving
    return sentinel.next
```
