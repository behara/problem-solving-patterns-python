# 02. Two Pointers

## When to use it

Sorted data or a pair/triple constraint lets you rule out candidates from an end.

## Core idea

Move the pointer whose movement can improve the current comparison.

## Example

In [1, 2, 4, 7], target 6 is found at indices (1, 2).

## Watch out

For 3Sum, sort a copy and skip duplicate anchors and pairs.

## Python implementation

The source is [`dsa_patterns/p02_two_pointers.py`](../dsa_patterns/p02_two_pointers.py). Functions document their time and space costs.

```python
"""Two pointers: exploit sorted order or opposing ends."""

def two_sum_sorted(nums: list[int], target: int) -> tuple[int, int] | None:
    """Return zero-based indices in sorted nums. O(n) time, O(1) space."""
    left, right = 0, len(nums) - 1
    while left < right:
        total = nums[left] + nums[right]
        if total == target:
            return left, right
        if total < target:
            left += 1
        else:
            right -= 1
    return None


def three_sum(nums: list[int]) -> list[tuple[int, int, int]]:
    """Unique triples summing to zero. O(n²) time, O(n) sorting space."""
    values = sorted(nums)
    result = []
    for i, first in enumerate(values):
        if i and first == values[i - 1]:
            continue
        left, right = i + 1, len(values) - 1
        while left < right:
            total = first + values[left] + values[right]
            if total < 0:
                left += 1
            elif total > 0:
                right -= 1
            else:
                result.append((first, values[left], values[right]))
                left += 1
                right -= 1
                while left < right and values[left] == values[left - 1]:
                    left += 1
    return result
```
