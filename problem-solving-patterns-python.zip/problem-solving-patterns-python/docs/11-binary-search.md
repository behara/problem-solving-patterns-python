# 11. Modified Binary Search

## When to use it

Input is sorted, rotated, or has a monotone decision boundary.

## Core idea

At each step identify a half that cannot contain the answer.

## Example

Searching 0 in [4,5,6,0,1,2] returns index 3.

## Watch out

The rotated-array version assumes distinct values.

## Python implementation

The source is [`dsa_patterns/p11_binary_search.py`](../dsa_patterns/p11_binary_search.py). Functions document their time and space costs.

```python
"""Modified binary search: choose the half that can contain the answer."""

def order_agnostic_search(nums: list[int], target: int) -> int:
    """Find target in ascending or descending sorted nums. O(log n) time."""
    if not nums:
        return -1
    ascending = nums[0] <= nums[-1]
    left, right = 0, len(nums) - 1
    while left <= right:
        mid = (left + right) // 2
        if nums[mid] == target:
            return mid
        if (nums[mid] < target) == ascending:
            left = mid + 1
        else:
            right = mid - 1
    return -1


def search_rotated(nums: list[int], target: int) -> int:
    """Find target in rotated ascending distinct array. O(log n) time."""
    left, right = 0, len(nums) - 1
    while left <= right:
        mid = (left + right) // 2
        if nums[mid] == target:
            return mid
        if nums[left] <= nums[mid]:
            if nums[left] <= target < nums[mid]:
                right = mid - 1
            else:
                left = mid + 1
        elif nums[mid] < target <= nums[right]:
            left = mid + 1
        else:
            right = mid - 1
    return -1
```
