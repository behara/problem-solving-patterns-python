# 18. Union Find (Disjoint Set)

## When to use it

Undirected connections arrive over time and component membership matters.

## Core idea

Compress find paths and attach smaller trees under larger trees.

## Example

Union(0,1) then union(1,2) leaves 0,1,2 in one component.

## Watch out

Union find does not itself answer directed reachability.

## Python implementation

The source is [`dsa_patterns/p18_union_find.py`](../dsa_patterns/p18_union_find.py). Functions document their time and space costs.

```python
"""Disjoint set union: maintain components as edges arrive."""
class DisjointSet:
    """Near-constant amortized find/union with compression and size ranking."""
    def __init__(self, size: int) -> None:
        if size < 0:
            raise ValueError("size must be nonnegative")
        self.parent = list(range(size))
        self.size = [1] * size
        self.components = size

    def find(self, value: int) -> int:
        if not 0 <= value < len(self.parent):
            raise IndexError(value)
        while value != self.parent[value]:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, first: int, second: int) -> bool:
        first, second = self.find(first), self.find(second)
        if first == second:
            return False
        if self.size[first] < self.size[second]:
            first, second = second, first
        self.parent[second] = first
        self.size[first] += self.size[second]
        self.components -= 1
        return True


def count_components(vertices: int, edges: list[tuple[int, int]]) -> int:
    """Connected components of an undirected graph. O(V+E α(V))."""
    sets = DisjointSet(vertices)
    for first, second in edges:
        sets.union(first, second)
    return sets.components
```
