# 10. Subsets and Permutations

## When to use it

A task asks to enumerate choices, orderings, or a power set.

## Core idea

Build partial solutions by adding each new value or recursively choosing unused values.

## Example

Subsets of [1,2] are [], [1], [2], [1,2].

## Watch out

Output size is exponential or factorial; include it in complexity.

## Python implementation

The source is [`dsa_patterns/p10_subsets.py`](../dsa_patterns/p10_subsets.py). Functions document their time and space costs.

```python
"""Subsets and permutations: grow partial choices."""

def subsets(nums: list[int]) -> list[list[int]]:
    """Power set, including empty set. O(n 2^n) time and output space."""
    result = [[]]
    for value in nums:
        result += [subset + [value] for subset in result]
    return result


def permutations(nums: list[int]) -> list[list[int]]:
    """Permutations of distinct values. O(n n!) time and output space."""
    if len(set(nums)) != len(nums):
        raise ValueError("nums must contain distinct values")
    result: list[list[int]] = []
    used = [False] * len(nums)
    path: list[int] = []
    def visit() -> None:
        if len(path) == len(nums):
            result.append(path.copy())
            return
        for i, value in enumerate(nums):
            if not used[i]:
                used[i] = True
                path.append(value)
                visit()
                path.pop()
                used[i] = False
    visit()
    return result
```
