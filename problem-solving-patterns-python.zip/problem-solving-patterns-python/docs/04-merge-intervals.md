# 04. Merge Intervals

## When to use it

Ranges must be combined, inserted, or checked for conflicts.

## Core idea

Sort by start, then extend the current merged interval when starts overlap.

## Example

[(1,3), (2,5), (8,9)] becomes [(1,5), (8,9)].

## Watch out

Decide whether touching endpoints overlap; these examples use closed intervals.

## Python implementation

The source is [`dsa_patterns/p04_merge_intervals.py`](../dsa_patterns/p04_merge_intervals.py). Functions document their time and space costs.

```python
"""Intervals: sort by start and maintain the current merged end."""

def merge_intervals(intervals: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """Merge closed overlapping intervals. O(n log n) time."""
    result: list[list[int]] = []
    for start, end in sorted(intervals):
        if start > end:
            raise ValueError("interval start exceeds end")
        if result and start <= result[-1][1]:
            result[-1][1] = max(result[-1][1], end)
        else:
            result.append([start, end])
    return [(start, end) for start, end in result]


def insert_interval(intervals: list[tuple[int, int]], new: tuple[int, int]) -> list[tuple[int, int]]:
    """Insert into sorted, disjoint closed intervals. O(n) time."""
    if new[0] > new[1]:
        raise ValueError("interval start exceeds end")
    result = []
    i = 0
    while i < len(intervals) and intervals[i][1] < new[0]:
        result.append(intervals[i])
        i += 1
    start, end = new
    while i < len(intervals) and intervals[i][0] <= end:
        start = min(start, intervals[i][0])
        end = max(end, intervals[i][1])
        i += 1
    return result + [(start, end)] + intervals[i:]
```
