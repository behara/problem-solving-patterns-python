# 01. Sliding Window

## When to use it

A question asks about contiguous subarrays or substrings.

## Core idea

Update a running window as its left and right boundaries move.

## Example

For [1, 3, 2, 6] with k=2, the largest window sum is 8, so its average is 4.

## Watch out

A shrinking sum window needs positive values; negative values break the monotonic argument.

## Python implementation

The source is [`dsa_patterns/p01_sliding_window.py`](../dsa_patterns/p01_sliding_window.py). Functions document their time and space costs.

```python
"""Sliding window: reuse work as a contiguous range moves."""

def maximum_average(nums: list[int], k: int) -> float:
    """Maximum average of a length-k subarray. O(n) time, O(1) space."""
    if not 1 <= k <= len(nums):
        raise ValueError("k must be between 1 and len(nums)")
    window = sum(nums[:k])
    best = window
    for right in range(k, len(nums)):
        window += nums[right] - nums[right - k]
        best = max(best, window)
    return best / k


def minimum_size_subarray_sum(target: int, nums: list[int]) -> int:
    """Shortest positive-integer window with sum >= target. O(n) time."""
    if target <= 0 or any(n <= 0 for n in nums):
        raise ValueError("target and array elements must be positive")
    left = total = 0
    best = len(nums) + 1
    for right, value in enumerate(nums):
        total += value
        while total >= target:
            best = min(best, right - left + 1)
            total -= nums[left]
            left += 1
    return 0 if best == len(nums) + 1 else best
```
