# 13. Top K Elements

## When to use it

A question asks for the kth largest value or most frequent few values.

## Core idea

Keep a heap of only candidates that still belong in the top k.

## Example

The 2nd largest of [3,2,1,5,6,4] is 5.

## Watch out

Specify tie behavior for equal frequencies.

## Python implementation

The source is [`dsa_patterns/p13_top_k.py`](../dsa_patterns/p13_top_k.py). Functions document their time and space costs.

```python
"""Top K: retain only candidates that can still win."""
from collections import Counter
import heapq

def kth_largest(nums: list[int], k: int) -> int:
    """Kth largest with a size-k min heap. O(n log k) time, O(k) space."""
    if not 1 <= k <= len(nums):
        raise ValueError("invalid k")
    heap = nums[:k]
    heapq.heapify(heap)
    for value in nums[k:]:
        if value > heap[0]:
            heapq.heapreplace(heap, value)
    return heap[0]


def top_k_frequent(nums: list[int], k: int) -> list[int]:
    """K most frequent values, ties by smaller value. O(n log k) time."""
    counts = Counter(nums)
    if not 0 <= k <= len(counts):
        raise ValueError("invalid k")
    return [value for value, _ in heapq.nsmallest(k, counts.items(), key=lambda item: (-item[1], item[0]))]
```
