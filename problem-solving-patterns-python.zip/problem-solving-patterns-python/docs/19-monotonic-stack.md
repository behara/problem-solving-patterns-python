# 19. Monotonic Stack

## When to use it

The next greater/smaller element or waiting distance is needed.

## Core idea

Keep unresolved indices in monotonic order; pop them when a new value resolves them.

## Example

Next greater values for [2,1,3] are [3,3,-1].

## Watch out

Store indices when the answer is a distance.

## Python implementation

The source is [`dsa_patterns/p19_monotonic_stack.py`](../dsa_patterns/p19_monotonic_stack.py). Functions document their time and space costs.

```python
"""Monotonic stack: discard candidates beaten by a new value."""

def next_greater_values(nums: list[int]) -> list[int]:
    """Next strictly greater value to the right or -1. O(n) time and space."""
    result = [-1] * len(nums)
    stack: list[int] = []
    for i, value in enumerate(nums):
        while stack and nums[stack[-1]] < value:
            result[stack.pop()] = value
        stack.append(i)
    return result


def daily_temperatures(temperatures: list[int]) -> list[int]:
    """Days until a warmer temperature or zero. O(n) time and space."""
    result = [0] * len(temperatures)
    stack: list[int] = []
    for i, value in enumerate(temperatures):
        while stack and temperatures[stack[-1]] < value:
            previous = stack.pop()
            result[previous] = i - previous
        stack.append(i)
    return result
```
