# 03. Fast and Slow Pointers

## When to use it

A linked list may contain a cycle, or you need its midpoint.

## Core idea

Advance one reference once and the other twice per iteration.

## Example

In 1 → 2 → 3 → 4, the second middle is node 3.

## Watch out

Check fast.next before advancing two links.

## Python implementation

The source is [`dsa_patterns/p03_fast_slow_pointers.py`](../dsa_patterns/p03_fast_slow_pointers.py). Functions document their time and space costs.

```python
"""Fast and slow pointers: detect cycles and find midpoints."""
from dataclasses import dataclass

@dataclass
class ListNode:
    value: int
    next: "ListNode | None" = None


def has_cycle(head: ListNode | None) -> bool:
    """Floyd cycle detection. O(n) time, O(1) space."""
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow is fast:
            return True
    return False


def middle_node(head: ListNode | None) -> ListNode | None:
    """Return second middle for even length. O(n) time, O(1) space."""
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    return slow
```
