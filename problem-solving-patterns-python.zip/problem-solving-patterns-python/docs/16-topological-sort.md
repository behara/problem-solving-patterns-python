# 16. Topological Sort

## When to use it

Tasks have directed prerequisites or dependency ordering.

## Core idea

Remove zero-indegree vertices and decrement their outgoing neighbors.

## Example

With edges 0→1 and 1→2, the order is [0,1,2].

## Watch out

A partial order indicates a directed cycle.

## Python implementation

The source is [`dsa_patterns/p16_topological_sort.py`](../dsa_patterns/p16_topological_sort.py). Functions document their time and space costs.

```python
"""Topological sorting: repeatedly remove zero-indegree vertices."""
from collections import deque

def topological_order(vertices: int, edges: list[tuple[int, int]]) -> list[int]:
    """Order a DAG; return [] for a cycle. O(V+E) time and space."""
    if vertices < 0:
        raise ValueError("vertices must be nonnegative")
    graph = [[] for _ in range(vertices)]
    indegree = [0] * vertices
    for before, after in edges:
        if not (0 <= before < vertices and 0 <= after < vertices):
            raise ValueError("edge endpoint out of range")
        graph[before].append(after)
        indegree[after] += 1
    queue = deque(i for i, degree in enumerate(indegree) if degree == 0)
    order = []
    while queue:
        vertex = queue.popleft()
        order.append(vertex)
        for neighbor in graph[vertex]:
            indegree[neighbor] -= 1
            if indegree[neighbor] == 0:
                queue.append(neighbor)
    return order if len(order) == vertices else []


def can_finish_courses(courses: int, prerequisites: list[tuple[int, int]]) -> bool:
    """Each pair is (course, prerequisite). O(V+E) time."""
    if courses == 0:
        return True
    return bool(topological_order(courses, [(pre, course) for course, pre in prerequisites]))
```
