# 14. K-way Merge

## When to use it

Several sorted sequences must be traversed as one.

## Core idea

Put the next item from each source in a min heap.

## Example

Merging [1,4] and [2,3] yields [1,2,3,4].

## Watch out

Store the source and position with each heap item.

## Python implementation

The source is [`dsa_patterns/p14_k_way_merge.py`](../dsa_patterns/p14_k_way_merge.py). Functions document their time and space costs.

```python
"""K-way merge: keep the next item from each sorted source in a heap."""
import heapq

def merge_sorted_lists(lists: list[list[int]]) -> list[int]:
    """Merge sorted arrays. O(N log k) time, O(k) extra space."""
    heap = [(items[0], source, 0) for source, items in enumerate(lists) if items]
    heapq.heapify(heap)
    result = []
    while heap:
        value, source, index = heapq.heappop(heap)
        result.append(value)
        if index + 1 < len(lists[source]):
            heapq.heappush(heap, (lists[source][index + 1], source, index + 1))
    return result


def kth_smallest_in_sorted_matrix(matrix: list[list[int]], k: int) -> int:
    """Kth value when each row is sorted. O(k log r) time, O(r) space."""
    total = sum(map(len, matrix))
    if not 1 <= k <= total:
        raise ValueError("invalid k")
    heap = [(row[0], i, 0) for i, row in enumerate(matrix) if row]
    heapq.heapify(heap)
    for _ in range(k):
        value, row, column = heapq.heappop(heap)
        if column + 1 < len(matrix[row]):
            heapq.heappush(heap, (matrix[row][column + 1], row, column + 1))
    return value
```
