# 17. Trie (Prefix Tree)

## When to use it

Many queries ask whether words or prefixes exist in a dictionary.

## Core idea

Store shared prefixes once, one character per edge.

## Example

After inserting 'cat', searches for 'cat' and prefix 'ca' succeed.

## Watch out

A word ending must be marked separately from merely having a prefix.

## Python implementation

The source is [`dsa_patterns/p17_trie.py`](../dsa_patterns/p17_trie.py). Functions document their time and space costs.

```python
"""Trie: share prefixes for repeated word and prefix queries."""
class Trie:
    """Insert/search/prefix in O(L) time per word, O(total characters) space."""
    def __init__(self) -> None:
        self.root: dict = {}

    def insert(self, word: str) -> None:
        node = self.root
        for char in word:
            node = node.setdefault(char, {})
        node[""] = True

    def search(self, word: str) -> bool:
        node = self._walk(word)
        return node is not None and "" in node

    def starts_with(self, prefix: str) -> bool:
        return self._walk(prefix) is not None

    def _walk(self, text: str) -> dict | None:
        node = self.root
        for char in text:
            if char not in node:
                return None
            node = node[char]
        return node


def replace_words(roots: list[str], sentence: str) -> str:
    """Replace each word by its shortest dictionary prefix. O(total characters)."""
    trie = Trie()
    for root in roots:
        trie.insert(root)
    def replace(word: str) -> str:
        node = trie.root
        for i, char in enumerate(word):
            if char not in node:
                break
            node = node[char]
            if "" in node:
                return word[:i + 1]
        return word
    return " ".join(replace(word) for word in sentence.split())
```
