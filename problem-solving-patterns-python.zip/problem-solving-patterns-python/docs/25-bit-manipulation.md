# 25. Bit Manipulation

## When to use it

The state is naturally a small set of bits or a fixed-width integer.

## Core idea

Use masks and bit identities such as n & (n-1) to clear the lowest set bit.

## Example

12 is binary 1100 and has two set bits.

## Watch out

Python integers have no fixed width; mask or bound values for 32-bit operations.

## Python implementation

The source is [`dsa_patterns/p25_bit_manipulation.py`](../dsa_patterns/p25_bit_manipulation.py). Functions document their time and space costs.

```python
"""Bit manipulation: masks, shifts, and fixed-width operations."""

def count_set_bits(value: int) -> int:
    """Count 1 bits of a nonnegative integer. O(number of set bits)."""
    if value < 0:
        raise ValueError("value must be nonnegative")
    count = 0
    while value:
        value &= value - 1
        count += 1
    return count


def reverse_bits_32(value: int) -> int:
    """Reverse exactly 32 bits. O(32) time, O(1) space."""
    if not 0 <= value < 2**32:
        raise ValueError("value must fit in unsigned 32 bits")
    result = 0
    for _ in range(32):
        result = (result << 1) | (value & 1)
        value >>= 1
    return result
```
