# 07. Tree Breadth-first Search

## When to use it

A tree question refers to levels, shortest root-to-leaf depth, or neighbors first.

## Core idea

Use a FIFO queue and process exactly the current queue length for each level.

## Example

For root 1 with children 2 and 3, levels are [[1], [2,3]].

## Watch out

For minimum depth, stop at a leaf, not at a node missing just one child.

## Python implementation

The source is [`dsa_patterns/p07_tree_bfs.py`](../dsa_patterns/p07_tree_bfs.py). Functions document their time and space costs.

```python
"""Tree breadth-first search: visit nodes level by level."""
from collections import deque
from dataclasses import dataclass

@dataclass
class TreeNode:
    value: int
    left: "TreeNode | None" = None
    right: "TreeNode | None" = None


def level_order(root: TreeNode | None) -> list[list[int]]:
    """Collect levels. O(n) time, O(w) queue space."""
    if root is None:
        return []
    queue = deque([root])
    levels = []
    while queue:
        level = []
        for _ in range(len(queue)):
            node = queue.popleft()
            level.append(node.value)
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        levels.append(level)
    return levels


def minimum_depth(root: TreeNode | None) -> int:
    """Shortest root-to-leaf distance in nodes. O(n) time, O(w) space."""
    if root is None:
        return 0
    queue = deque([(root, 1)])
    while queue:
        node, depth = queue.popleft()
        if node.left is None and node.right is None:
            return depth
        if node.left:
            queue.append((node.left, depth + 1))
        if node.right:
            queue.append((node.right, depth + 1))
    raise AssertionError("unreachable")
```
