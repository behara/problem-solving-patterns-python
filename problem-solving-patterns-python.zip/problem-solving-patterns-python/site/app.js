(async () => {
  const nav = document.getElementById('nav');
  const main = document.getElementById('main');
  const search = document.getElementById('search');
  let patterns;
  try {
    const response = await fetch('./patterns.json');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    patterns = await response.json();
  } catch (error) {
    main.innerHTML = '<h1>Could not load patterns</h1><p class="error">Run <code>python3 -m http.server 8000</code> from the repository root, then open <code>/site/</code>.</p>';
    return;
  }
  const heading = (label, value) => {
    const section = document.createElement('section');
    const h = document.createElement('h2');
    h.textContent = label;
    const p = document.createElement('p');
    p.textContent = value;
    section.append(h, p);
    return section;
  };
  function show(pattern) {
    location.hash = pattern.slug;
    main.replaceChildren();
    const tag = document.createElement('div');
    tag.className = 'tag';
    tag.textContent = `Pattern ${String(pattern.id).padStart(2, '0')}`;
    const title = document.createElement('h1');
    title.textContent = pattern.title;
    main.append(tag, title);
    main.append(heading('When to use it', pattern.cue));
    main.append(heading('Core idea', pattern.idea));
    main.append(heading('Example', pattern.example));
    const caution = heading('Watch out', pattern.trap);
    caution.className = 'note';
    main.append(caution);
    const links = document.createElement('div');
    links.className = 'links';
    const doc = document.createElement('a');
    doc.href = `../docs/${pattern.doc}`;
    doc.textContent = 'Read pattern note ↗';
    const source = document.createElement('a');
    source.href = `../dsa_patterns/${pattern.module}.py`;
    source.textContent = 'Open Python source ↗';
    links.append(doc, source);
    main.append(links);
    const codeTitle = document.createElement('h2');
    codeTitle.textContent = 'Python implementation';
    const pre = document.createElement('pre');
    const code = document.createElement('code');
    code.textContent = pattern.source;
    pre.append(code);
    main.append(codeTitle, pre);
    for (const button of nav.querySelectorAll('button')) {
      button.classList.toggle('active', button.dataset.slug === pattern.slug);
    }
    main.focus();
  }
  function renderNav() {
    const query = search.value.trim().toLowerCase();
    nav.replaceChildren();
    for (const pattern of patterns) {
      if (!`${pattern.title} ${pattern.cue} ${pattern.idea}`.toLowerCase().includes(query)) continue;
      const button = document.createElement('button');
      button.type = 'button';
      button.dataset.slug = pattern.slug;
      button.textContent = `${String(pattern.id).padStart(2, '0')}  ${pattern.title}`;
      button.addEventListener('click', () => show(pattern));
      nav.append(button);
    }
  }
  search.addEventListener('input', renderNav);
  window.addEventListener('hashchange', () => {
    const selected = patterns.find(pattern => pattern.slug === location.hash.slice(1));
    if (selected) show(selected);
  });
  renderNav();
  show(patterns.find(pattern => pattern.slug === location.hash.slice(1)) || patterns[0]);
})();
