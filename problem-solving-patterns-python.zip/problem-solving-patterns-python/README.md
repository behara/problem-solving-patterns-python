# Problem Solving Patterns in Python

A fresh Python companion to the [26-pattern reference](https://github.com/rohitkr7/problem-solving-patterns). Each pattern has a concise note and runnable, standard-library-only Python implementations. The examples include representative problems from [AlgoMaster's DSA pattern practice list](https://algomaster.io/practice/dsa-patterns), alongside classic interview patterns from the reference repo. This repository is independently authored; it does not copy the other repo's Git history or Java solutions.

## Explore

- Read the [pattern notes](docs/) or browse the table below.
- Run `python3 -m unittest discover -s tests -v` from the repo root.
- Run `python3 -m http.server 8000`, then open [http://localhost:8000/site/](http://localhost:8000/site/) to browse and search the patterns locally.
- Import directly, for example `from dsa_patterns.p01_sliding_window import maximum_average`.

Python 3.10+ is required. There are no third-party runtime dependencies. The browser viewer loads the generated `site/patterns.json`; after editing source or pattern metadata, run `python3 scripts/generate_site.py` to rebuild the notes and catalog.

## Pattern index

| # | Pattern notes | Python source |
|---:|---|---|
| 01 | [Sliding Window](docs/01-sliding-window.md) | [`p01_sliding_window.py`](dsa_patterns/p01_sliding_window.py) |
| 02 | [Two Pointers](docs/02-two-pointers.md) | [`p02_two_pointers.py`](dsa_patterns/p02_two_pointers.py) |
| 03 | [Fast and Slow Pointers](docs/03-fast-slow-pointers.md) | [`p03_fast_slow_pointers.py`](dsa_patterns/p03_fast_slow_pointers.py) |
| 04 | [Merge Intervals](docs/04-merge-intervals.md) | [`p04_merge_intervals.py`](dsa_patterns/p04_merge_intervals.py) |
| 05 | [Cyclic Sort](docs/05-cyclic-sort.md) | [`p05_cyclic_sort.py`](dsa_patterns/p05_cyclic_sort.py) |
| 06 | [In-place Linked List Reversal](docs/06-reverse-linked-list.md) | [`p06_reverse_linked_list.py`](dsa_patterns/p06_reverse_linked_list.py) |
| 07 | [Tree Breadth-first Search](docs/07-tree-bfs.md) | [`p07_tree_bfs.py`](dsa_patterns/p07_tree_bfs.py) |
| 08 | [Tree Depth-first Search](docs/08-tree-dfs.md) | [`p08_tree_dfs.py`](dsa_patterns/p08_tree_dfs.py) |
| 09 | [Two Heaps](docs/09-two-heaps.md) | [`p09_two_heaps.py`](dsa_patterns/p09_two_heaps.py) |
| 10 | [Subsets and Permutations](docs/10-subsets.md) | [`p10_subsets.py`](dsa_patterns/p10_subsets.py) |
| 11 | [Modified Binary Search](docs/11-binary-search.md) | [`p11_binary_search.py`](dsa_patterns/p11_binary_search.py) |
| 12 | [Bitwise XOR](docs/12-bitwise-xor.md) | [`p12_bitwise_xor.py`](dsa_patterns/p12_bitwise_xor.py) |
| 13 | [Top K Elements](docs/13-top-k.md) | [`p13_top_k.py`](dsa_patterns/p13_top_k.py) |
| 14 | [K-way Merge](docs/14-k-way-merge.md) | [`p14_k_way_merge.py`](dsa_patterns/p14_k_way_merge.py) |
| 15 | [0/1 Knapsack and Dynamic Programming](docs/15-knapsack-dp.md) | [`p15_knapsack_dp.py`](dsa_patterns/p15_knapsack_dp.py) |
| 16 | [Topological Sort](docs/16-topological-sort.md) | [`p16_topological_sort.py`](dsa_patterns/p16_topological_sort.py) |
| 17 | [Trie (Prefix Tree)](docs/17-trie.md) | [`p17_trie.py`](dsa_patterns/p17_trie.py) |
| 18 | [Union Find (Disjoint Set)](docs/18-union-find.md) | [`p18_union_find.py`](dsa_patterns/p18_union_find.py) |
| 19 | [Monotonic Stack](docs/19-monotonic-stack.md) | [`p19_monotonic_stack.py`](dsa_patterns/p19_monotonic_stack.py) |
| 20 | [Prefix Sum](docs/20-prefix-sum.md) | [`p20_prefix_sum.py`](dsa_patterns/p20_prefix_sum.py) |
| 21 | [Island / Matrix Traversal](docs/21-islands.md) | [`p21_islands.py`](dsa_patterns/p21_islands.py) |
| 22 | [Backtracking](docs/22-backtracking.md) | [`p22_backtracking.py`](dsa_patterns/p22_backtracking.py) |
| 23 | [Shortest Path](docs/23-shortest-path.md) | [`p23_shortest_path.py`](dsa_patterns/p23_shortest_path.py) |
| 24 | [Greedy Algorithms](docs/24-greedy.md) | [`p24_greedy.py`](dsa_patterns/p24_greedy.py) |
| 25 | [Bit Manipulation](docs/25-bit-manipulation.md) | [`p25_bit_manipulation.py`](dsa_patterns/p25_bit_manipulation.py) |
| 26 | [Data Structure Design](docs/26-data-structure-design.md) | [`p26_data_structure_design.py`](dsa_patterns/p26_data_structure_design.py) |

## Conventions

Inputs and return values are described in each function docstring. In-place operations say so explicitly. Indices are zero-based unless a function says otherwise. Error cases raise `ValueError` for invalid constraints and `IndexError` for invalid range access.
