"""Fast and slow pointers: detect cycles and find midpoints."""
from dataclasses import dataclass

@dataclass
class ListNode:
    value: int
    next: "ListNode | None" = None


def has_cycle(head: ListNode | None) -> bool:
    """Floyd cycle detection. O(n) time, O(1) space."""
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow is fast:
            return True
    return False


def middle_node(head: ListNode | None) -> ListNode | None:
    """Return second middle for even length. O(n) time, O(1) space."""
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    return slow
