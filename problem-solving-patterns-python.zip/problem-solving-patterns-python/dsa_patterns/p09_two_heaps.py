"""Two heaps: keep lower and upper halves balanced."""
import heapq

class MedianFinder:
    """Streaming median. O(log n) add; O(1) median; O(n) space."""
    def __init__(self) -> None:
        self.lower: list[int] = []  # Negated max heap.
        self.upper: list[int] = []

    def add(self, value: int) -> None:
        heapq.heappush(self.lower, -value)
        heapq.heappush(self.upper, -heapq.heappop(self.lower))
        if len(self.upper) > len(self.lower):
            heapq.heappush(self.lower, -heapq.heappop(self.upper))

    def median(self) -> float:
        if not self.lower:
            raise ValueError("no values")
        if len(self.lower) > len(self.upper):
            return float(-self.lower[0])
        return (-self.lower[0] + self.upper[0]) / 2


def maximize_capital(capital: int, projects: int, required: list[int], profit: list[int]) -> int:
    """Pick up to projects affordable jobs for maximum capital. O(n log n + k log n)."""
    if len(required) != len(profit) or projects < 0 or any(p < 0 for p in profit):
        raise ValueError("invalid projects")
    available = []
    index = 0
    jobs = sorted(zip(required, profit))
    for _ in range(projects):
        while index < len(jobs) and jobs[index][0] <= capital:
            heapq.heappush(available, -jobs[index][1])
            index += 1
        if not available or available[0] == 0:
            break
        capital -= heapq.heappop(available)
    return capital
