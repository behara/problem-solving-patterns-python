"""Cyclic placement: put a value at its natural index."""

def cyclic_sort(nums: list[int]) -> list[int]:
    """Sort a permutation of 1..n in place. O(n) time, O(1) space."""
    if any(value < 1 or value > len(nums) for value in nums):
        raise ValueError("nums must be a permutation of 1..n")
    i = 0
    while i < len(nums):
        correct = nums[i] - 1
        if nums[i] != nums[correct]:
            nums[i], nums[correct] = nums[correct], nums[i]
        else:
            i += 1
    if any(value != i + 1 for i, value in enumerate(nums)):
        raise ValueError("nums must be a permutation of 1..n")
    return nums


def first_missing_positive(nums: list[int]) -> int:
    """Smallest absent positive integer; mutates nums. O(n) time, O(1) space."""
    n = len(nums)
    for i in range(n):
        while 1 <= nums[i] <= n and nums[nums[i] - 1] != nums[i]:
            j = nums[i] - 1
            nums[i], nums[j] = nums[j], nums[i]
    for i, value in enumerate(nums):
        if value != i + 1:
            return i + 1
    return n + 1
