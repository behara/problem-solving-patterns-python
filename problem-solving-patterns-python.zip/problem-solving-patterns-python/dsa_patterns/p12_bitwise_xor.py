"""XOR: equal values cancel, leaving unmatched bits."""

def single_number(nums: list[int]) -> int:
    """One value occurs once; all others twice. O(n) time, O(1) space."""
    result = 0
    for value in nums:
        result ^= value
    return result


def two_single_numbers(nums: list[int]) -> tuple[int, int]:
    """Two values occur once; all others twice. O(n) time, O(1) space."""
    combined = single_number(nums)
    if combined == 0:
        raise ValueError("two distinct singleton values required")
    low_bit = combined & -combined
    first = second = 0
    for value in nums:
        if value & low_bit:
            first ^= value
        else:
            second ^= value
    return first, second
