"""Trie: share prefixes for repeated word and prefix queries."""
class Trie:
    """Insert/search/prefix in O(L) time per word, O(total characters) space."""
    def __init__(self) -> None:
        self.root: dict = {}

    def insert(self, word: str) -> None:
        node = self.root
        for char in word:
            node = node.setdefault(char, {})
        node[""] = True

    def search(self, word: str) -> bool:
        node = self._walk(word)
        return node is not None and "" in node

    def starts_with(self, prefix: str) -> bool:
        return self._walk(prefix) is not None

    def _walk(self, text: str) -> dict | None:
        node = self.root
        for char in text:
            if char not in node:
                return None
            node = node[char]
        return node


def replace_words(roots: list[str], sentence: str) -> str:
    """Replace each word by its shortest dictionary prefix. O(total characters)."""
    trie = Trie()
    for root in roots:
        trie.insert(root)
    def replace(word: str) -> str:
        node = trie.root
        for i, char in enumerate(word):
            if char not in node:
                break
            node = node[char]
            if "" in node:
                return word[:i + 1]
        return word
    return " ".join(replace(word) for word in sentence.split())
