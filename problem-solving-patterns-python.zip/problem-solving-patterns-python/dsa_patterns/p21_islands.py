"""Grid traversal: treat cells as vertices with implicit neighbors."""
from collections import deque

DIRECTIONS = ((1, 0), (-1, 0), (0, 1), (0, -1))

def count_islands(grid: list[list[str]]) -> int:
    """Count 4-connected groups of '1'; does not mutate grid. O(RC) time."""
    if not grid:
        return 0
    if any(len(row) != len(grid[0]) for row in grid):
        raise ValueError("grid must be rectangular")
    rows, cols = len(grid), len(grid[0])
    seen = set()
    islands = 0
    for row in range(rows):
        for col in range(cols):
            if grid[row][col] != "1" or (row, col) in seen:
                continue
            islands += 1
            stack = [(row, col)]
            seen.add((row, col))
            while stack:
                r, c = stack.pop()
                for dr, dc in DIRECTIONS:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == "1" and (nr, nc) not in seen:
                        seen.add((nr, nc))
                        stack.append((nr, nc))
    return islands


def minutes_to_rot(grid: list[list[int]]) -> int:
    """Minutes to spread rot from all rotten cells, or -1. Mutates grid. O(RC)."""
    if not grid:
        return 0
    if any(len(row) != len(grid[0]) for row in grid):
        raise ValueError("grid must be rectangular")
    rows, cols = len(grid), len(grid[0])
    queue = deque((r, c, 0) for r in range(rows) for c in range(cols) if grid[r][c] == 2)
    fresh = sum(value == 1 for row in grid for value in row)
    minutes = 0
    while queue:
        row, col, minutes = queue.popleft()
        for dr, dc in DIRECTIONS:
            nr, nc = row + dr, col + dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 1:
                grid[nr][nc] = 2
                fresh -= 1
                queue.append((nr, nc, minutes + 1))
    return -1 if fresh else minutes
