"""Greedy algorithms: commit to a locally safe choice."""

def max_nonoverlapping_intervals(intervals: list[tuple[int, int]]) -> int:
    """Maximum number of half-open compatible intervals. O(n log n) time."""
    if any(start > end for start, end in intervals):
        raise ValueError("interval start exceeds end")
    count = 0
    last_end = float("-inf")
    for start, end in sorted(intervals, key=lambda item: item[1]):
        if start >= last_end:
            count += 1
            last_end = end
    return count


def can_jump(nums: list[int]) -> bool:
    """Reach final index using nonnegative jump lengths. O(n) time, O(1) space."""
    if any(value < 0 for value in nums):
        raise ValueError("jump lengths must be nonnegative")
    farthest = 0
    for index, jump in enumerate(nums):
        if index > farthest:
            return False
        farthest = max(farthest, index + jump)
    return True
