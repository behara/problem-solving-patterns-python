"""Tree depth-first search: explore one branch before another."""
from .p07_tree_bfs import TreeNode

def has_path_sum(root: TreeNode | None, target: int) -> bool:
    """Whether any root-to-leaf path sums to target. O(n) time, O(h) stack."""
    if root is None:
        return False
    if root.left is None and root.right is None:
        return root.value == target
    return has_path_sum(root.left, target - root.value) or has_path_sum(root.right, target - root.value)


def path_sum(root: TreeNode | None, target: int) -> list[list[int]]:
    """All root-to-leaf paths summing to target. O(nh) output-inclusive space."""
    result: list[list[int]] = []
    path: list[int] = []
    def visit(node: TreeNode | None, remaining: int) -> None:
        if node is None:
            return
        path.append(node.value)
        remaining -= node.value
        if node.left is None and node.right is None and remaining == 0:
            result.append(path.copy())
        visit(node.left, remaining)
        visit(node.right, remaining)
        path.pop()
    visit(root, target)
    return result
