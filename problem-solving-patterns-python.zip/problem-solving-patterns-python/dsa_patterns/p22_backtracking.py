"""Backtracking: choose, recurse, and undo a choice."""

def combinations(n: int, k: int) -> list[list[int]]:
    """Choose k values from 1..n. O(k * C(n,k)) output-inclusive time."""
    if n < 0 or not 0 <= k <= n:
        raise ValueError("invalid n or k")
    result: list[list[int]] = []
    path: list[int] = []
    def visit(start: int) -> None:
        if len(path) == k:
            result.append(path.copy())
            return
        for value in range(start, n - (k - len(path)) + 2):
            path.append(value)
            visit(value + 1)
            path.pop()
    visit(1)
    return result


def word_exists(board: list[list[str]], word: str) -> bool:
    """Find a word along adjacent cells without cell reuse. O(RC * 3^L)."""
    if not word:
        return True
    if not board:
        return False
    rows, cols = len(board), len(board[0])
    if any(len(row) != cols for row in board):
        raise ValueError("board must be rectangular")
    used: set[tuple[int, int]] = set()
    def visit(row: int, col: int, index: int) -> bool:
        if index == len(word):
            return True
        if not (0 <= row < rows and 0 <= col < cols) or (row, col) in used or board[row][col] != word[index]:
            return False
        used.add((row, col))
        found = any(visit(row + dr, col + dc, index + 1) for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        used.remove((row, col))
        return found
    return any(visit(r, c, 0) for r in range(rows) for c in range(cols))
