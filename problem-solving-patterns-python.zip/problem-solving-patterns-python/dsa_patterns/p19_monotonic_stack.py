"""Monotonic stack: discard candidates beaten by a new value."""

def next_greater_values(nums: list[int]) -> list[int]:
    """Next strictly greater value to the right or -1. O(n) time and space."""
    result = [-1] * len(nums)
    stack: list[int] = []
    for i, value in enumerate(nums):
        while stack and nums[stack[-1]] < value:
            result[stack.pop()] = value
        stack.append(i)
    return result


def daily_temperatures(temperatures: list[int]) -> list[int]:
    """Days until a warmer temperature or zero. O(n) time and space."""
    result = [0] * len(temperatures)
    stack: list[int] = []
    for i, value in enumerate(temperatures):
        while stack and temperatures[stack[-1]] < value:
            previous = stack.pop()
            result[previous] = i - previous
        stack.append(i)
    return result
