"""Modified binary search: choose the half that can contain the answer."""

def order_agnostic_search(nums: list[int], target: int) -> int:
    """Find target in ascending or descending sorted nums. O(log n) time."""
    if not nums:
        return -1
    ascending = nums[0] <= nums[-1]
    left, right = 0, len(nums) - 1
    while left <= right:
        mid = (left + right) // 2
        if nums[mid] == target:
            return mid
        if (nums[mid] < target) == ascending:
            left = mid + 1
        else:
            right = mid - 1
    return -1


def search_rotated(nums: list[int], target: int) -> int:
    """Find target in rotated ascending distinct array. O(log n) time."""
    left, right = 0, len(nums) - 1
    while left <= right:
        mid = (left + right) // 2
        if nums[mid] == target:
            return mid
        if nums[left] <= nums[mid]:
            if nums[left] <= target < nums[mid]:
                right = mid - 1
            else:
                left = mid + 1
        elif nums[mid] < target <= nums[right]:
            left = mid + 1
        else:
            right = mid - 1
    return -1
