"""Representative behavior and boundary checks for all 26 patterns."""
import unittest
from math import inf
from dsa_patterns import (
    p01_sliding_window as p01, p02_two_pointers as p02, p03_fast_slow_pointers as p03,
    p04_merge_intervals as p04, p05_cyclic_sort as p05, p06_reverse_linked_list as p06,
    p07_tree_bfs as p07, p08_tree_dfs as p08, p09_two_heaps as p09,
    p10_subsets as p10, p11_binary_search as p11, p12_bitwise_xor as p12,
    p13_top_k as p13, p14_k_way_merge as p14, p15_knapsack_dp as p15,
    p16_topological_sort as p16, p17_trie as p17, p18_union_find as p18,
    p19_monotonic_stack as p19, p20_prefix_sum as p20, p21_islands as p21,
    p22_backtracking as p22, p23_shortest_path as p23, p24_greedy as p24,
    p25_bit_manipulation as p25, p26_data_structure_design as p26,
)

class PatternTests(unittest.TestCase):
    def test_01_sliding_window(self):
        self.assertEqual(p01.maximum_average([1, 3, 2, 6], 2), 4)
        self.assertEqual(p01.minimum_size_subarray_sum(7, [2, 3, 1, 2, 4, 3]), 2)
        self.assertEqual(p01.minimum_size_subarray_sum(100, [1, 2]), 0)

    def test_02_two_pointers(self):
        self.assertEqual(p02.two_sum_sorted([1, 2, 4, 7], 6), (1, 2))
        self.assertEqual(p02.three_sum([-1, 0, 1, 2, -1, -4]), [(-1, -1, 2), (-1, 0, 1)])

    def test_03_fast_slow(self):
        head = p03.ListNode(1, p03.ListNode(2, p03.ListNode(3)))
        self.assertEqual(p03.middle_node(head).value, 2)
        self.assertFalse(p03.has_cycle(head))
        head.next.next.next = head
        self.assertTrue(p03.has_cycle(head))

    def test_04_intervals(self):
        self.assertEqual(p04.merge_intervals([(1, 3), (2, 5), (8, 9)]), [(1, 5), (8, 9)])
        self.assertEqual(p04.insert_interval([(1, 2), (5, 6)], (2, 5)), [(1, 6)])

    def test_05_cyclic(self):
        self.assertEqual(p05.cyclic_sort([3, 1, 2]), [1, 2, 3])
        self.assertEqual(p05.first_missing_positive([3, 4, -1, 1]), 2)
        with self.assertRaises(ValueError):
            p05.cyclic_sort([1, 1])

    def test_06_reversal(self):
        head = p03.ListNode(1, p03.ListNode(2, p03.ListNode(3)))
        self.assertEqual(p06.reverse_list(head).value, 3)
        head = p03.ListNode(1, p03.ListNode(2, p03.ListNode(3)))
        result = p06.reverse_between(head, 1, 2)
        self.assertEqual([result.value, result.next.value, result.next.next.value], [2, 1, 3])

    def test_07_tree_bfs(self):
        root = p07.TreeNode(1, p07.TreeNode(2), p07.TreeNode(3))
        self.assertEqual(p07.level_order(root), [[1], [2, 3]])
        self.assertEqual(p07.minimum_depth(root), 2)
        self.assertEqual(p07.minimum_depth(None), 0)

    def test_08_tree_dfs(self):
        root = p07.TreeNode(5, p07.TreeNode(4, p07.TreeNode(1)), p07.TreeNode(8))
        self.assertTrue(p08.has_path_sum(root, 10))
        self.assertEqual(p08.path_sum(root, 10), [[5, 4, 1]])

    def test_09_heaps(self):
        median = p09.MedianFinder()
        for value in [2, 7, 4]:
            median.add(value)
        self.assertEqual(median.median(), 4)
        self.assertEqual(p09.maximize_capital(0, 2, [0, 1, 1], [1, 2, 3]), 4)

    def test_10_subsets(self):
        self.assertEqual(len(p10.subsets([1, 2, 3])), 8)
        self.assertEqual(len(p10.permutations([1, 2, 3])), 6)
        self.assertEqual(p10.permutations([]), [[]])

    def test_11_binary_search(self):
        self.assertEqual(p11.order_agnostic_search([7, 5, 3], 5), 1)
        self.assertEqual(p11.search_rotated([4, 5, 6, 0, 1, 2], 0), 3)
        self.assertEqual(p11.search_rotated([], 4), -1)

    def test_12_xor(self):
        self.assertEqual(p12.single_number([3, 5, 3]), 5)
        self.assertEqual(set(p12.two_single_numbers([1, 2, 1, 3])), {2, 3})

    def test_13_top_k(self):
        self.assertEqual(p13.kth_largest([3, 2, 1, 5, 6, 4], 2), 5)
        self.assertEqual(p13.top_k_frequent([1, 1, 2, 2, 3], 2), [1, 2])

    def test_14_merge(self):
        self.assertEqual(p14.merge_sorted_lists([[1, 4], [2, 3], []]), [1, 2, 3, 4])
        self.assertEqual(p14.kth_smallest_in_sorted_matrix([[1, 4], [2, 3]], 3), 3)

    def test_15_dp(self):
        self.assertEqual(p15.knapsack_01([2, 3], [4, 5], 3), 5)
        self.assertTrue(p15.can_partition_equal([1, 5, 11, 5]))
        self.assertFalse(p15.can_partition_equal([1, 2, 3, 5]))

    def test_16_topological(self):
        self.assertEqual(p16.topological_order(3, [(0, 1), (1, 2)]), [0, 1, 2])
        self.assertEqual(p16.topological_order(2, [(0, 1), (1, 0)]), [])
        self.assertFalse(p16.can_finish_courses(2, [(0, 1), (1, 0)]))

    def test_17_trie(self):
        trie = p17.Trie()
        trie.insert('cat')
        self.assertTrue(trie.search('cat'))
        self.assertFalse(trie.search('ca'))
        self.assertTrue(trie.starts_with('ca'))
        self.assertEqual(p17.replace_words(['cat', 'bat'], 'the cattle bat'), 'the cat bat')

    def test_18_union_find(self):
        sets = p18.DisjointSet(3)
        self.assertTrue(sets.union(0, 1))
        self.assertFalse(sets.union(0, 1))
        self.assertEqual(sets.components, 2)
        self.assertEqual(p18.count_components(4, [(0, 1), (1, 2)]), 2)

    def test_19_stack(self):
        self.assertEqual(p19.next_greater_values([2, 1, 3]), [3, 3, -1])
        self.assertEqual(p19.daily_temperatures([73, 74, 75, 71, 69, 72, 76, 73]), [1, 1, 4, 2, 1, 1, 0, 0])

    def test_20_prefix(self):
        self.assertEqual(p20.RangeSum([1, 2, 3]).query(1, 2), 5)
        self.assertEqual(p20.count_subarrays_with_sum([1, -1, 0], 0), 3)

    def test_21_islands(self):
        self.assertEqual(p21.count_islands([['1', '0'], ['1', '1']]), 1)
        self.assertEqual(p21.minutes_to_rot([[2, 1], [1, 1]]), 2)
        self.assertEqual(p21.minutes_to_rot([[1]]), -1)

    def test_22_backtracking(self):
        self.assertEqual(p22.combinations(3, 2), [[1, 2], [1, 3], [2, 3]])
        self.assertTrue(p22.word_exists([['A', 'B'], ['C', 'D']], 'ABD'))
        self.assertFalse(p22.word_exists([['A', 'B'], ['C', 'D']], 'ABA'))

    def test_23_paths(self):
        self.assertEqual(p23.dijkstra({0: [(1, 2)], 1: [(2, 3)]}, 0)[2], 5)
        self.assertEqual(p23.bellman_ford(3, [(0, 1, 2), (1, 2, -3)], 0), [0, 2, -1])
        with self.assertRaises(ValueError):
            p23.dijkstra({0: [(1, -1)]}, 0)

    def test_24_greedy(self):
        self.assertEqual(p24.max_nonoverlapping_intervals([(1, 2), (2, 3), (1, 3)]), 2)
        self.assertTrue(p24.can_jump([2, 3, 1, 1, 4]))
        self.assertFalse(p24.can_jump([3, 2, 1, 0, 4]))

    def test_25_bits(self):
        self.assertEqual(p25.count_set_bits(12), 2)
        self.assertEqual(p25.reverse_bits_32(1), 2**31)
        with self.assertRaises(ValueError):
            p25.count_set_bits(-1)

    def test_26_design(self):
        cache = p26.LRUCache(2)
        cache.put(1, 10)
        cache.put(2, 20)
        self.assertEqual(cache.get(1), 10)
        cache.put(3, 30)
        self.assertEqual(cache.get(2), -1)
        values = p26.RandomizedSet()
        self.assertTrue(values.insert(1))
        self.assertTrue(values.insert(2))
        self.assertTrue(values.remove(1))
        self.assertEqual(values.get_random(), 2)

if __name__ == '__main__':
    unittest.main()
